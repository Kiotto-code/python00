# name = "ft_package"
# version = "1.0.0"
from .ft_package import count_in_list
