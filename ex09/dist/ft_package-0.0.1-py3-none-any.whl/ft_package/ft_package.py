# ft_package/hello.py
def say_hello(name):
    return f"Hello, {name}! This is ft_package."


def count_in_list(arr: list, target: str) -> int:
    return arr.count(target)
